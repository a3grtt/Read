
import React from "react";
import { motion } from "framer-motion";

const groups = [
  {
    name: "BTS",
    bio: "BTS is a 7-member South Korean boy band formed by BigHit. They are known for their powerful performances and deep lyrics.",
    discography: ["Dynamite", "Butter", "Boy With Luv", "Fake Love"],
  },
  {
    name: "BLACKPINK",
    bio: "BLACKPINK is a global girl group formed by YG Entertainment. They blend fierce confidence with catchy music.",
    discography: ["DDU-DU DDU-DU", "How You Like That", "Kill This Love"],
  },
  {
    name: "NewJeans",
    bio: "NewJeans is a Gen-Z K-pop girl group under ADOR, known for their Y2K fashion and chill sound.",
    discography: ["Hype Boy", "OMG", "Ditto"],
  },
];

export default function KpopNeonSite() {
  return (
    <motion.div
      style={{ background: "black", color: "white", padding: "2rem", fontFamily: "sans-serif" }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <h1 style={{ fontSize: "3rem", color: "#ff00c8", textShadow: "0 0 10px #ff00c8, 0 0 20px #ff00c8" }}>K-POP UNIVERSE</h1>
      <p>Your all-in-one hub for everything K-pop</p>

      <div style={{ marginTop: "2rem" }}>
        {groups.map((group) => (
          <div key={group.name} style={{ marginBottom: "1.5rem", border: "1px solid #ff00c8", padding: "1rem" }}>
            <h2 style={{ color: "#ff00c8" }}>{group.name}</h2>
            <p>{group.bio}</p>
            <p><strong>Top Tracks:</strong></p>
            <ul>
              {group.discography.map((track) => (
                <li key={track}>{track}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
