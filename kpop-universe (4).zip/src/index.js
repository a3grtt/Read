
import React from "react";
import { createRoot } from "react-dom/client";
import KpopNeonSite from "./KpopNeonSite";

const root = createRoot(document.getElementById("root"));
root.render(<KpopNeonSite />);
